# ICE SMP PvP Tier Testing Website

## Preview locally
1. Extract the ZIP.
2. Open `index.html` in a modern browser.

## Publish online with GitHub Pages
1. Sign in to GitHub and create a new public repository (for example `ice-smp-tier-testing`).
2. Upload `index.html` to the repository root.
3. Open Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish the site. Your public URL will be shown in Settings → Pages.

## Important limitations
This is a static, browser-only website. Player data is saved in the visitor's own browser, not shared between visitors. It has no real login, server-side database, or admin permissions. For a public community tier list where everyone sees the same data, connect a backend such as Supabase or Firebase and add authentication/security rules before launch.
